//
//  Title.swift
//  StepikSwift1M4_2
//
//  Created by Ivan Vasilyev on 24/07/2019.
//  Copyright © 2019 Ivan Vasilyev. All rights reserved.
//

import Foundation

class Title {
    var text: String
    
    init(text: String) {
        self.text = text
    }
}
